import "./TrackLoader.css";

function TrackLoader({ label = "Loading..." }) {
  return (
    <div className="track-loader" role="status" aria-live="polite">
      <div className="track-loader-stage">
        <div className="track-loader-ring" />
        <span className="track-loader-flag" />

        <div className="track-loader-orbit">
          <svg
            className="track-loader-car"
            viewBox="0 0 40 64"
            aria-hidden="true"
          >
            <rect x="2" y="12" width="6" height="12" rx="3" fill="#1f2937" />
            <rect x="32" y="12" width="6" height="12" rx="3" fill="#1f2937" />
            <rect x="2" y="40" width="6" height="12" rx="3" fill="#1f2937" />
            <rect x="32" y="40" width="6" height="12" rx="3" fill="#1f2937" />
            <rect x="6" y="4" width="28" height="56" rx="12" fill="#ef4444" />
            <path
              d="M11 16 Q20 10 29 16 L27 25 Q20 21 13 25 Z"
              fill="#fee2e2"
            />
            <path
              d="M13 44 Q20 41 27 44 L29 50 Q20 47 11 50 Z"
              fill="#fecaca"
            />
            <rect x="12" y="27" width="16" height="14" rx="5" fill="#b91c1c" />
          </svg>
        </div>
      </div>

      <p className="track-loader-text">{label}</p>
    </div>
  );
}

export default TrackLoader;
