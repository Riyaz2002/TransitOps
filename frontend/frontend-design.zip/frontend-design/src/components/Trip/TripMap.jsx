import "./TripMap.css";

// Approximate coordinates for the cities used across the app. Unknown cities
// fall back to a sensible diagonal so the route still renders.
const CITY_COORDS = {
  chennai: { lat: 13.08, lng: 80.27 },
  coimbatore: { lat: 11.02, lng: 76.96 },
  madurai: { lat: 9.93, lng: 78.12 },
  trichy: { lat: 10.79, lng: 78.7 },
  tiruchirappalli: { lat: 10.79, lng: 78.7 },
  salem: { lat: 11.66, lng: 78.15 },
  bengaluru: { lat: 12.97, lng: 77.59 },
  bangalore: { lat: 12.97, lng: 77.59 },
  vellore: { lat: 12.92, lng: 79.13 },
  erode: { lat: 11.34, lng: 77.72 },
  tirupur: { lat: 11.11, lng: 77.34 },
  thanjavur: { lat: 10.79, lng: 79.14 },
  kochi: { lat: 9.93, lng: 76.27 },
  hyderabad: { lat: 17.39, lng: 78.49 },
  mumbai: { lat: 19.08, lng: 72.88 },
  pune: { lat: 18.52, lng: 73.86 },
  delhi: { lat: 28.61, lng: 77.21 },
  kolkata: { lat: 22.57, lng: 88.36 },
  ahmedabad: { lat: 23.02, lng: 72.57 },
};

const BOX = { l: 40, r: 320, t: 48, b: 168 };
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
const key = (s) => (s || "").trim().toLowerCase();

const toPixel = (nx, ny) => ({
  x: BOX.l + nx * (BOX.r - BOX.l),
  y: BOX.t + ny * (BOX.b - BOX.t),
});

function positions(source, destination) {
  const a = CITY_COORDS[key(source)];
  const b = CITY_COORDS[key(destination)];

  if (a && b) {
    const minLng = Math.min(a.lng, b.lng);
    const maxLng = Math.max(a.lng, b.lng);
    const minLat = Math.min(a.lat, b.lat);
    const maxLat = Math.max(a.lat, b.lat);
    const spanLng = maxLng - minLng || 1;
    const spanLat = maxLat - minLat || 1;
    const pad = (t) => 0.16 + t * 0.68;

    return {
      A: toPixel(pad((a.lng - minLng) / spanLng), pad(1 - (a.lat - minLat) / spanLat)),
      B: toPixel(pad((b.lng - minLng) / spanLng), pad(1 - (b.lat - minLat) / spanLat)),
      geo: true,
    };
  }

  return { A: toPixel(0.2, 0.74), B: toPixel(0.82, 0.28), geo: false };
}

function Pin({ point, className }) {
  return (
    <g transform={`translate(${point.x} ${point.y})`} className={className}>
      <path
        className="trip-pin-body"
        d="M0 0 c-7 -8 -11 -12 -11 -18 a11 11 0 1 1 22 0 c0 6 -4 10 -11 18 z"
      />
      <circle className="trip-pin-dot" cx="0" cy="-18" r="4.5" />
    </g>
  );
}

function TripMap({ source, destination, distance, status }) {
  const { A, B, geo } = positions(source, destination);

  const mx = (A.x + B.x) / 2;
  const my = (A.y + B.y) / 2;
  const dx = B.x - A.x;
  const dy = B.y - A.y;
  const len = Math.hypot(dx, dy) || 1;
  const off = Math.min(58, len * 0.24);
  const cx = mx + (-dy / len) * off;
  const cy = my + (dx / len) * off;
  const routeD = `M ${A.x} ${A.y} Q ${cx} ${cy} ${B.x} ${B.y}`;

  return (
    <div className="trip-map">
      <div className="trip-map-head">
        <div className="trip-map-head-text">
          <span className="trip-map-title">Trip route</span>
          <span className="trip-map-sub">
            {source || "?"} <span className="trip-map-arrow">→</span>{" "}
            {destination || "?"}
          </span>
        </div>
        {distance ? (
          <span className="trip-map-distance">{distance} km</span>
        ) : status ? (
          <span className="trip-map-distance">{status}</span>
        ) : null}
      </div>

      <div className="trip-map-canvas">
        <svg viewBox="0 0 360 216" role="img" aria-label={`Route from ${source} to ${destination}`}>
          <rect className="trip-map-bg" x="0" y="0" width="360" height="216" rx="16" />

          {/* faint map grid */}
          <g className="trip-map-grid">
            <line x1="0" y1="54" x2="360" y2="54" />
            <line x1="0" y1="108" x2="360" y2="108" />
            <line x1="0" y1="162" x2="360" y2="162" />
            <line x1="90" y1="0" x2="90" y2="216" />
            <line x1="180" y1="0" x2="180" y2="216" />
            <line x1="270" y1="0" x2="270" y2="216" />
          </g>

          {/* decorative faint roads */}
          <g className="trip-map-roads">
            <path d="M-10 150 C 90 120 150 175 260 130 S 380 90 380 96" />
            <path d="M40 -10 C 70 60 130 70 150 140 S 210 220 240 226" />
          </g>

          {/* the route */}
          <path
            id="tripRoutePath"
            className="trip-route-line"
            d={routeD}
            fill="none"
          />
          <path className="trip-route-glow" d={routeD} fill="none" />

          <Pin point={A} className="trip-pin start" />
          <Pin point={B} className="trip-pin end" />

          {/* moving car following the route */}
          <g>
            <rect
              className="trip-car-body"
              x="-10"
              y="-5.5"
              width="20"
              height="11"
              rx="4.5"
            />
            <rect
              className="trip-car-glass"
              x="1"
              y="-3.4"
              width="6"
              height="6.8"
              rx="2"
            />
            <animateMotion dur="4.5s" repeatCount="indefinite" rotate="auto">
              <mpath href="#tripRoutePath" />
            </animateMotion>
          </g>

          {/* labels */}
          <text
            className="trip-map-label"
            x={clamp(A.x, 30, 330)}
            y={A.y + 20}
            textAnchor="middle"
          >
            {source}
          </text>
          <text
            className="trip-map-label"
            x={clamp(B.x, 30, 330)}
            y={B.y - 30}
            textAnchor="middle"
          >
            {destination}
          </text>
        </svg>
      </div>

      <div className="trip-map-legend">
        <span className="trip-map-leg start">Start · {source}</span>
        <span className="trip-map-leg end">Destination · {destination}</span>
        {!geo && (
          <span className="trip-map-leg note">Schematic route</span>
        )}
      </div>
    </div>
  );
}

export default TripMap;
