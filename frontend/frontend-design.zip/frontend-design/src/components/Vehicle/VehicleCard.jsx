import "./VehicleCard.css";

const fmtNumber = (value) =>
  value === null || value === undefined || value === ""
    ? "—"
    : Number(value).toLocaleString("en-IN");

const fmtMoney = (value) =>
  value === null || value === undefined || value === ""
    ? "—"
    : `₹${Number(value).toLocaleString("en-IN")}`;

const mediaFallback = (
  <span className="vehicle-media-fallback" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      <rect x="1" y="4" width="15" height="12" rx="1.5" />
      <path d="M16 8h3.5L23 11.5V16H16z" />
      <circle cx="6" cy="18.5" r="2" />
      <circle cx="18" cy="18.5" r="2" />
    </svg>
  </span>
);

function VehicleCard({ vehicle, isSelected, onSelectVehicle }) {
  const statusClass = (vehicle.status || "")
    .toLowerCase()
    .replace(/\s+/g, "-");

  return (
    <button
      type="button"
      className={isSelected ? "vehicle-card selected" : "vehicle-card"}
      onClick={() => onSelectVehicle(vehicle)}
    >
      <div className="vehicle-media">
        {vehicle.image ? (
          <img
            src={vehicle.image}
            alt={vehicle.model_name}
            className="vehicle-image"
          />
        ) : (
          mediaFallback
        )}
        <span className={`status-badge ${statusClass}`}>{vehicle.status}</span>
      </div>

      <div className="vehicle-content">
        <div className="vehicle-card-heading">
          <h3>{vehicle.model_name}</h3>
          <p className="vehicle-kicker">{vehicle.vehicle_type}</p>
        </div>

        <div className="vehicle-detail-grid">
          <div className="vehicle-detail vehicle-detail--wide">
            <span className="vehicle-detail-label">Registration</span>
            <span className="vehicle-detail-value">
              {vehicle.registration_number}
            </span>
          </div>
          <div className="vehicle-detail">
            <span className="vehicle-detail-label">Max Load</span>
            <span className="vehicle-detail-value">
              {fmtNumber(vehicle.max_load_capacity)} kg
            </span>
          </div>
          <div className="vehicle-detail">
            <span className="vehicle-detail-label">Odometer</span>
            <span className="vehicle-detail-value">
              {fmtNumber(vehicle.odometer)} km
            </span>
          </div>
          <div className="vehicle-detail vehicle-detail--wide">
            <span className="vehicle-detail-label">Acquisition Cost</span>
            <span className="vehicle-detail-value">
              {fmtMoney(vehicle.acquisition_cost)}
            </span>
          </div>
        </div>
      </div>
    </button>
  );
}

export default VehicleCard;
