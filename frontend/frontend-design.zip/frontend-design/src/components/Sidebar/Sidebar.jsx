import { NavLink, useNavigate } from "react-router-dom";
import "./Sidebar.css";

const iconProps = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

const icons = {
  dashboard: (
    <svg {...iconProps} aria-hidden="true">
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </svg>
  ),
  vehicle: (
    <svg {...iconProps} aria-hidden="true">
      <rect x="1" y="4" width="15" height="12" rx="1.5" />
      <path d="M16 8h3.5L23 11.5V16H16z" />
      <circle cx="6" cy="18.5" r="2" />
      <circle cx="18" cy="18.5" r="2" />
    </svg>
  ),
  driver: (
    <svg {...iconProps} aria-hidden="true">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  ),
  trip: (
    <svg {...iconProps} aria-hidden="true">
      <polygon points="1 6 8 3 16 6 23 3 23 18 16 21 8 18 1 21" />
      <line x1="8" y1="3" x2="8" y2="18" />
      <line x1="16" y1="6" x2="16" y2="21" />
    </svg>
  ),
  logout: (
    <svg {...iconProps} aria-hidden="true">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
  ),
};

const menuItems = [
  { label: "Dashboard", path: "/dashboard", icon: "dashboard" },
  { label: "Vehicle", path: "/vehicle", icon: "vehicle" },
  { label: "Driver", path: "/driver", icon: "driver" },
  { label: "Trip", path: "/trip", icon: "trip" },
];

function Sidebar({ darkMode, hidden, setHidden, mobileOpen, closeMobile }) {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("data_mode");
    navigate("/");
  };

  const className = [
    "sidebar",
    darkMode ? "dark" : "",
    hidden ? "hidden" : "",
    mobileOpen ? "mobile-open" : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className={className}>
      <button
        type="button"
        className="sidebar-close"
        aria-label="Close menu"
        onClick={closeMobile}
      >
        <svg {...iconProps} aria-hidden="true">
          <line x1="18" y1="6" x2="6" y2="18" />
          <line x1="6" y1="6" x2="18" y2="18" />
        </svg>
      </button>

      <button
        type="button"
        className="sidebar-toggle"
        aria-label={hidden ? "Show menu" : "Hide menu"}
        aria-expanded={!hidden}
        onClick={() => setHidden(!hidden)}
      >
        <svg {...iconProps} aria-hidden="true">
          <line x1="3" y1="6" x2="21" y2="6" />
          <line x1="3" y1="12" x2="21" y2="12" />
          <line x1="3" y1="18" x2="21" y2="18" />
        </svg>
      </button>

      <div className="sidebar-header">
        <span className="sidebar-logo">{icons.vehicle}</span>
        <div className="sidebar-header-text">
          <h2>Fleet Registry</h2>
          <p>Transit Ops</p>
        </div>
      </div>

      <nav className="menu-grid">
        {menuItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            onClick={closeMobile}
            className={({ isActive }) =>
              `menu-item${isActive ? " active" : ""}`
            }
          >
            <span className="menu-icon">{icons[item.icon]}</span>
            <span className="menu-label">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <button type="button" className="logout-btn" onClick={handleLogout}>
        <span className="logout-icon">{icons.logout}</span>
        <span className="logout-text">Logout</span>
      </button>
    </div>
  );
}

export default Sidebar;
