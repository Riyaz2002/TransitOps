import { useEffect, useMemo, useState } from "react";
import "../Vehicle/Vehicle.css";
import driversData from "../../data/drivers";
import TrackLoader from "../../components/Loader/TrackLoader";
import {
  createDriverApi,
  getDriversApi,
  updateDriverApi,
} from "../../api/driverApi";

const emptyDriver = {
  name: "",
  license_number: "",
  license_category: "LMV",
  license_expiry_date: "",
  contact_number: "",
  safety_score: "",
  status: "Available",
  image: "",
};

// Maps the form onto the backend Driver schema, coercing numeric fields.
const buildPayload = (data) => ({
  name: data.name,
  license_number: data.license_number,
  license_category: data.license_category,
  license_expiry_date: data.license_expiry_date,
  contact_number: data.contact_number,
  safety_score: Number(data.safety_score || 0),
  status: data.status,
  image: data.image || "",
});

const driverFallback = (
  <span className="vehicle-media-fallback" aria-hidden="true">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  </span>
);

function Driver({ dataMode }) {
  const [drivers, setDrivers] = useState(driversData);
  const [selectedDriver, setSelectedDriver] = useState(null);
  const [formData, setFormData] = useState(emptyDriver);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortKey, setSortKey] = useState("name");

  const isEditing = Boolean(selectedDriver);
  const isApiMode = dataMode === "api";

  useEffect(() => {
    const loadDrivers = async () => {
      setError("");
      setShowForm(false);
      setSelectedDriver(null);
      setFormData(emptyDriver);

      if (!isApiMode) {
        setDrivers(driversData);
        return;
      }

      setIsLoading(true);
      try {
        const response = await getDriversApi();
        setDrivers(Array.isArray(response) ? response : []);
      } catch {
        setDrivers([]);
        setError("Unable to load API driver records.");
      } finally {
        setIsLoading(false);
      }
    };

    loadDrivers();
  }, [isApiMode]);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((currentData) => ({
      ...currentData,
      [name]: value,
    }));
  };

  const handleCreate = () => {
    setSelectedDriver(null);
    setFormData(emptyDriver);
    setShowForm(true);
    setError("");
  };

  const handleSelect = (driver) => {
    setSelectedDriver(driver);
    setFormData({ ...emptyDriver, ...driver });
    setShowForm(true);
    setError("");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setIsSaving(true);

    const payload = buildPayload(formData);

    try {
      if (isEditing) {
        const updated = isApiMode
          ? await updateDriverApi(selectedDriver.id, payload)
          : { ...payload, id: selectedDriver.id, image: formData.image };

        setDrivers((current) =>
          current.map((driver) =>
            driver.id === selectedDriver.id ? updated : driver,
          ),
        );
        setSelectedDriver(updated);
        setFormData({ ...emptyDriver, ...updated });
        return;
      }

      const created = isApiMode
        ? await createDriverApi(payload)
        : { ...payload, id: Date.now(), image: formData.image };

      setDrivers((current) => [created, ...current]);
      setSelectedDriver(created);
      setFormData({ ...emptyDriver, ...created });
      setShowForm(true);
    } catch {
      setError("Unable to save driver record.");
    } finally {
      setIsSaving(false);
    }
  };

  const filteredDrivers = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    const matches = drivers.filter((driver) => {
      if (!query) {
        return true;
      }

      return [
        driver.name,
        driver.license_number,
        driver.license_category,
        driver.contact_number,
        driver.status,
      ]
        .join(" ")
        .toLowerCase()
        .includes(query);
    });

    return [...matches].sort((a, b) => {
      if (sortKey === "status") {
        return (a.status || "").localeCompare(b.status || "");
      }
      if (sortKey === "safety_score") {
        return (b.safety_score || 0) - (a.safety_score || 0);
      }
      return (a.name || "").localeCompare(b.name || "");
    });
  }, [searchTerm, sortKey, drivers]);

  // Backend has no delete endpoint, so removal is local to the current view.
  const handleDelete = () => {
    if (!selectedDriver) {
      return;
    }

    setDrivers((current) =>
      current.filter((driver) => driver.id !== selectedDriver.id),
    );
    setSelectedDriver(null);
    setFormData(emptyDriver);
    setShowForm(false);
  };

  return (
    <div className="vehicle-page">
      <div className="vehicle-actions">
        <div className="vehicle-toolbar">
          <p>
            {isLoading
              ? "Loading drivers..."
              : `${filteredDrivers.length} drivers registered`}
            <span className="vehicle-mode-label">
              {isApiMode ? "API Mode" : "Dummy Mode"}
            </span>
          </p>
          <div className="vehicle-filter-bar">
            <input
              type="text"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder="Search drivers"
            />
            <select
              value={sortKey}
              onChange={(event) => setSortKey(event.target.value)}
            >
              <option value="name">Sort by name</option>
              <option value="status">Sort by status</option>
              <option value="safety_score">Sort by safety score</option>
            </select>
          </div>
        </div>
        <button
          type="button"
          className="create-vehicle-btn"
          onClick={handleCreate}
        >
          Add Driver
        </button>
      </div>

      {error && <p className="vehicle-error">{error}</p>}

      <div className="vehicle-manager">
        {isLoading ? (
          <TrackLoader label="Loading drivers..." />
        ) : (
          <div className="vehicle-grid">
            {filteredDrivers.map((driver) => (
              <article
                key={driver.id}
                className={`vehicle-card${selectedDriver?.id === driver.id ? " selected" : ""}`}
                onClick={() => handleSelect(driver)}
              >
                <div className="vehicle-media">
                  {driver.image ? (
                    <img
                      src={driver.image}
                      alt={driver.name}
                      className="vehicle-image"
                    />
                  ) : (
                    driverFallback
                  )}
                  <span
                    className={`status-badge ${(driver.status || "").toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {driver.status}
                  </span>
                </div>

                <div className="vehicle-content">
                  <div className="vehicle-card-heading">
                    <h3>{driver.name}</h3>
                    <p className="vehicle-kicker">
                      {driver.license_category} Licence
                    </p>
                  </div>

                  <div className="vehicle-detail-grid">
                    <div className="vehicle-detail vehicle-detail--wide">
                      <span className="vehicle-detail-label">License No.</span>
                      <span className="vehicle-detail-value">
                        {driver.license_number}
                      </span>
                    </div>
                    <div className="vehicle-detail">
                      <span className="vehicle-detail-label">Contact</span>
                      <span className="vehicle-detail-value">
                        {driver.contact_number}
                      </span>
                    </div>
                    <div className="vehicle-detail">
                      <span className="vehicle-detail-label">Safety</span>
                      <span className="vehicle-detail-value">
                        {driver.safety_score}
                      </span>
                    </div>
                    <div className="vehicle-detail vehicle-detail--wide">
                      <span className="vehicle-detail-label">
                        License Expiry
                      </span>
                      <span className="vehicle-detail-value">
                        {driver.license_expiry_date}
                      </span>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {showForm && (
          <form className="vehicle-form" onSubmit={handleSubmit}>
            <div className="vehicle-form-header">
              <div>
                <h2>{isEditing ? "Edit Driver" : "Create Driver"}</h2>
                <p>{isEditing ? formData.name : "New record"}</p>
              </div>

              <button
                type="button"
                className="close-form-btn"
                aria-label="Close driver form"
                onClick={() => setShowForm(false)}
              >
                x
              </button>
            </div>

            <label>
              Driver Name
              <input
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Driver name"
                required
              />
            </label>

            <label>
              License Number
              <input
                name="license_number"
                value={formData.license_number}
                onChange={handleChange}
                placeholder="TN0123456789"
                required
              />
            </label>

            <div className="vehicle-form-row">
              <label>
                License Category
                <select
                  name="license_category"
                  value={formData.license_category}
                  onChange={handleChange}
                >
                  <option>LMV</option>
                  <option>HMV</option>
                  <option>MCWG</option>
                  <option>Transport</option>
                </select>
              </label>

              <label>
                License Expiry
                <input
                  name="license_expiry_date"
                  type="date"
                  value={formData.license_expiry_date}
                  onChange={handleChange}
                  required
                />
              </label>
            </div>

            <label>
              Contact Number
              <input
                name="contact_number"
                value={formData.contact_number}
                onChange={handleChange}
                placeholder="+91 98765 43210"
                required
              />
            </label>

            <div className="vehicle-form-row">
              <label>
                Safety Score
                <input
                  name="safety_score"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.safety_score}
                  onChange={handleChange}
                  placeholder="96"
                />
              </label>

              <label>
                Status
                <select
                  name="status"
                  value={formData.status}
                  onChange={handleChange}
                >
                  <option>Available</option>
                  <option>On Trip</option>
                  <option>Off Duty</option>
                  <option>Suspended</option>
                </select>
              </label>
            </div>

            <label>
              Image URL (optional)
              <input
                name="image"
                value={formData.image || ""}
                onChange={handleChange}
                placeholder="https://..."
              />
            </label>

            <div className="vehicle-form-buttons">
              <button
                type="submit"
                className="save-vehicle-btn"
                disabled={isSaving}
              >
                {isSaving
                  ? "Saving..."
                  : isEditing
                    ? "Save Changes"
                    : "Create Record"}
              </button>

              {isEditing && (
                <button
                  type="button"
                  className="delete-vehicle-btn"
                  onClick={handleDelete}
                >
                  Delete
                </button>
              )}
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default Driver;
