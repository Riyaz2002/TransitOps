import { useEffect, useMemo, useState } from "react";
import "../Vehicle/Vehicle.css";
import tripData from "../../data/trips";
import vehiclesData from "../../data/vehicles";
import driversData from "../../data/drivers";
import TrackLoader from "../../components/Loader/TrackLoader";
import TripMap from "../../components/Trip/TripMap";
import { createTripApi, getTripsApi, updateTripApi } from "../../api/tripApi";
import { getVehiclesApi } from "../../api/vehicleApi";
import { getDriversApi } from "../../api/driverApi";

const emptyTrip = {
  trip_number: "",
  source: "",
  destination: "",
  vehicle_id: "",
  driver_id: "",
  cargo_weight: "",
  planned_distance: "",
  actual_distance: "",
  start_odometer: "",
  end_odometer: "",
  fuel_consumed: "",
  status: "Draft",
};

function Trip({ dataMode }) {
  const [trips, setTrips] = useState(tripData);
  const [vehicleList, setVehicleList] = useState(vehiclesData);
  const [driverList, setDriverList] = useState(driversData);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [formData, setFormData] = useState(emptyTrip);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortKey, setSortKey] = useState("trip_number");

  const isEditing = Boolean(selectedTrip);
  const isApiMode = dataMode === "api";

  useEffect(() => {
    const loadAll = async () => {
      setError("");
      setShowForm(false);
      setSelectedTrip(null);
      setFormData(emptyTrip);

      if (!isApiMode) {
        setTrips(tripData);
        setVehicleList(vehiclesData);
        setDriverList(driversData);
        return;
      }

      setIsLoading(true);
      try {
        const [tripsRes, vehiclesRes, driversRes] = await Promise.all([
          getTripsApi(),
          getVehiclesApi().catch(() => []),
          getDriversApi().catch(() => []),
        ]);
        setTrips(Array.isArray(tripsRes) ? tripsRes : []);
        setVehicleList(Array.isArray(vehiclesRes) ? vehiclesRes : []);
        setDriverList(Array.isArray(driversRes) ? driversRes : []);
      } catch {
        setError("Unable to load trips from API.");
        setTrips([]);
      } finally {
        setIsLoading(false);
      }
    };

    loadAll();
  }, [isApiMode]);

  // Resolve vehicle/driver ids to display names from the loaded lists.
  const vehicleNameById = useMemo(() => {
    const map = {};
    vehicleList.forEach((v) => {
      map[v.id] = v.model_name || v.registration_number || `Vehicle #${v.id}`;
    });
    return map;
  }, [vehicleList]);

  const driverNameById = useMemo(() => {
    const map = {};
    driverList.forEach((d) => {
      map[d.id] = d.name || `Driver #${d.id}`;
    });
    return map;
  }, [driverList]);

  const getVehicleName = (id) =>
    id ? vehicleNameById[Number(id)] || "Unassigned" : "Unassigned";
  const getDriverName = (id) =>
    id ? driverNameById[Number(id)] || "Unassigned" : "Unassigned";

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((currentData) => ({ ...currentData, [name]: value }));
  };

  const handleCreate = () => {
    setSelectedTrip(null);
    setFormData(emptyTrip);
    setShowForm(true);
    setError("");
  };

  const handleSelect = (trip) => {
    setSelectedTrip(trip);
    setFormData({ ...emptyTrip, ...trip });
    setShowForm(true);
    setError("");
  };

  const filteredTrips = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    const matches = trips.filter((trip) => {
      if (!query) {
        return true;
      }

      return [trip.trip_number, trip.source, trip.destination, trip.status]
        .join(" ")
        .toLowerCase()
        .includes(query);
    });

    return [...matches].sort((a, b) => {
      if (sortKey === "status") {
        return (a.status || "").localeCompare(b.status || "");
      }
      if (sortKey === "destination") {
        return (a.destination || "").localeCompare(b.destination || "");
      }
      return (a.trip_number || "").localeCompare(b.trip_number || "");
    });
  }, [searchTerm, sortKey, trips]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");

    try {
      const payload = {
        ...formData,
        vehicle_id: formData.vehicle_id ? Number(formData.vehicle_id) : null,
        driver_id: formData.driver_id ? Number(formData.driver_id) : null,
        cargo_weight: Number(formData.cargo_weight || 0),
        planned_distance: Number(formData.planned_distance || 0),
        actual_distance: formData.actual_distance
          ? Number(formData.actual_distance)
          : null,
        start_odometer: Number(formData.start_odometer || 0),
        end_odometer: Number(formData.end_odometer || 0),
        fuel_consumed: formData.fuel_consumed
          ? Number(formData.fuel_consumed)
          : null,
      };

      const savedTrip = isEditing
        ? isApiMode
          ? await updateTripApi(selectedTrip.id, payload)
          : { ...payload, id: selectedTrip.id }
        : isApiMode
          ? await createTripApi(payload)
          : { ...payload, id: Date.now() };

      setTrips((currentTrips) =>
        isEditing
          ? currentTrips.map((trip) =>
              trip.id === savedTrip.id ? savedTrip : trip,
            )
          : [savedTrip, ...currentTrips],
      );
      setSelectedTrip(savedTrip);
      setFormData({ ...emptyTrip, ...savedTrip });
      setShowForm(true);
    } catch {
      setError("Unable to save trip.");
    }
  };

  const showMap = Boolean(formData.source && formData.destination);

  return (
    <div className="vehicle-page">
      <div className="vehicle-actions">
        <div className="vehicle-toolbar">
          <p>
            {isLoading ? "Loading trips..." : `${filteredTrips.length} trips`}
            <span className="vehicle-mode-label">
              {isApiMode ? "API Mode" : "Dummy Mode"}
            </span>
          </p>
          <div className="vehicle-filter-bar">
            <input
              type="text"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder="Search trips"
            />
            <select
              value={sortKey}
              onChange={(event) => setSortKey(event.target.value)}
            >
              <option value="trip_number">Sort by trip</option>
              <option value="status">Sort by status</option>
              <option value="destination">Sort by destination</option>
            </select>
          </div>
        </div>
        <button
          type="button"
          className="create-vehicle-btn"
          onClick={handleCreate}
        >
          Add Trip
        </button>
      </div>

      {error && <p className="vehicle-error">{error}</p>}

      <div className="vehicle-manager">
        {isLoading ? (
          <TrackLoader label="Loading trips..." />
        ) : (
          <div className="vehicle-grid">
            {filteredTrips.map((trip) => (
              <article
                key={trip.id}
                className={`vehicle-card trip-card${selectedTrip?.id === trip.id ? " selected" : ""}`}
                onClick={() => handleSelect(trip)}
              >
                <div className="vehicle-content">
                  <div className="trip-heading">
                    <div className="trip-heading-text">
                      <h3>{trip.trip_number || `Trip #${trip.id}`}</h3>
                      <p className="trip-route">
                        <span>{trip.source}</span>
                        <span className="trip-route-arrow">→</span>
                        <span>{trip.destination}</span>
                      </p>
                    </div>
                    <span
                      className={`status-badge ${(trip.status || "").toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      {trip.status}
                    </span>
                  </div>

                  <div className="vehicle-detail-grid">
                    <div className="vehicle-detail">
                      <span className="vehicle-detail-label">Vehicle</span>
                      <span className="vehicle-detail-value">
                        {getVehicleName(trip.vehicle_id)}
                      </span>
                    </div>
                    <div className="vehicle-detail">
                      <span className="vehicle-detail-label">Driver</span>
                      <span className="vehicle-detail-value">
                        {getDriverName(trip.driver_id)}
                      </span>
                    </div>
                    <div className="vehicle-detail">
                      <span className="vehicle-detail-label">Cargo</span>
                      <span className="vehicle-detail-value">
                        {trip.cargo_weight} kg
                      </span>
                    </div>
                    <div className="vehicle-detail">
                      <span className="vehicle-detail-label">Distance</span>
                      <span className="vehicle-detail-value">
                        {trip.planned_distance} km
                      </span>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {showForm && (
          <form className="vehicle-form" onSubmit={handleSubmit}>
            <div className="vehicle-form-header">
              <div>
                <h2>{isEditing ? "Edit Trip" : "Create Trip"}</h2>
                <p>
                  {isEditing
                    ? formData.trip_number || `Trip #${formData.id}`
                    : "New record"}
                </p>
              </div>
              <button
                type="button"
                className="close-form-btn"
                onClick={() => setShowForm(false)}
              >
                x
              </button>
            </div>

            {showMap && (
              <TripMap
                source={formData.source}
                destination={formData.destination}
                distance={formData.planned_distance}
                status={formData.status}
              />
            )}

            <label>
              Trip Number
              <input
                name="trip_number"
                value={formData.trip_number || ""}
                onChange={handleChange}
                placeholder="TRIP-001"
              />
            </label>
            <label>
              Source
              <input
                name="source"
                value={formData.source || ""}
                onChange={handleChange}
                required
              />
            </label>
            <label>
              Destination
              <input
                name="destination"
                value={formData.destination || ""}
                onChange={handleChange}
                required
              />
            </label>
            <label>
              Vehicle
              <select
                name="vehicle_id"
                value={formData.vehicle_id || ""}
                onChange={handleChange}
              >
                <option value="">Select vehicle</option>
                {vehicleList.map((vehicle) => (
                  <option key={vehicle.id} value={vehicle.id}>
                    {vehicle.model_name || vehicle.registration_number}
                  </option>
                ))}
              </select>
            </label>
            <label>
              Driver
              <select
                name="driver_id"
                value={formData.driver_id || ""}
                onChange={handleChange}
              >
                <option value="">Select driver</option>
                {driverList.map((driver) => (
                  <option key={driver.id} value={driver.id}>
                    {driver.name}
                  </option>
                ))}
              </select>
            </label>
            <div className="vehicle-form-row">
              <label>
                Cargo Weight (kg)
                <input
                  name="cargo_weight"
                  type="number"
                  min="0"
                  value={formData.cargo_weight || ""}
                  onChange={handleChange}
                />
              </label>
              <label>
                Planned Distance (km)
                <input
                  name="planned_distance"
                  type="number"
                  min="0"
                  value={formData.planned_distance || ""}
                  onChange={handleChange}
                />
              </label>
            </div>
            <div className="vehicle-form-row">
              <label>
                Actual Distance (km)
                <input
                  name="actual_distance"
                  type="number"
                  min="0"
                  value={formData.actual_distance || ""}
                  onChange={handleChange}
                />
              </label>
              <label>
                Fuel Consumed (L)
                <input
                  name="fuel_consumed"
                  type="number"
                  min="0"
                  value={formData.fuel_consumed || ""}
                  onChange={handleChange}
                />
              </label>
            </div>
            <div className="vehicle-form-row">
              <label>
                Start Odometer
                <input
                  name="start_odometer"
                  type="number"
                  min="0"
                  value={formData.start_odometer || ""}
                  onChange={handleChange}
                />
              </label>
              <label>
                End Odometer
                <input
                  name="end_odometer"
                  type="number"
                  min="0"
                  value={formData.end_odometer || ""}
                  onChange={handleChange}
                />
              </label>
            </div>
            <label>
              Status
              <select
                name="status"
                value={formData.status || "Draft"}
                onChange={handleChange}
              >
                <option>Draft</option>
                <option>Dispatched</option>
                <option>Completed</option>
                <option>Cancelled</option>
              </select>
            </label>
            <div className="vehicle-form-buttons">
              <button type="submit" className="save-vehicle-btn">
                Save
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default Trip;
