import { useEffect, useMemo, useState } from "react";
import "./Vehicle.css";
import VehicleGrid from "../../components/Vehicle/VehicleGrid";
import TrackLoader from "../../components/Loader/TrackLoader";
import vehicleData from "../../data/vehicles";
import {
  createVehicleApi,
  getVehiclesApi,
  updateVehicleApi,
} from "../../api/vehicleApi";

const emptyVehicle = {
  registration_number: "",
  model_name: "",
  vehicle_type: "",
  max_load_capacity: "",
  odometer: "",
  acquisition_cost: "",
  status: "Available",
  image: "",
};

// Maps the form onto the backend Vehicle schema, coercing numeric fields.
const buildPayload = (data) => ({
  registration_number: data.registration_number,
  model_name: data.model_name,
  vehicle_type: data.vehicle_type,
  max_load_capacity: Number(data.max_load_capacity || 0),
  odometer: Number(data.odometer || 0),
  acquisition_cost: Number(data.acquisition_cost || 0),
  status: data.status,
  image: data.image || "",
});

function Vehicle({ dataMode }) {
  const [vehicles, setVehicles] = useState(vehicleData);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [formData, setFormData] = useState(emptyVehicle);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortKey, setSortKey] = useState("model_name");

  const isEditing = Boolean(selectedVehicle);
  const isApiMode = dataMode === "api";

  useEffect(() => {
    const loadVehicles = async () => {
      setError("");
      setShowForm(false);
      setSelectedVehicle(null);
      setFormData(emptyVehicle);

      if (!isApiMode) {
        setVehicles(vehicleData);
        return;
      }

      setIsLoading(true);

      try {
        const response = await getVehiclesApi();
        const apiVehicles = Array.isArray(response)
          ? response
          : response.results || [];
        setVehicles(apiVehicles);
      } catch {
        setVehicles([]);
        setError("Unable to load API vehicle records.");
      } finally {
        setIsLoading(false);
      }
    };

    loadVehicles();
  }, [isApiMode]);

  const handleChange = (event) => {
    const { name, value } = event.target;

    setFormData((currentData) => ({
      ...currentData,
      [name]: value,
    }));
  };

  const handleCreate = () => {
    setSelectedVehicle(null);
    setFormData(emptyVehicle);
    setShowForm(true);
    setError("");
  };

  const handleSelect = (vehicle) => {
    setSelectedVehicle(vehicle);
    setFormData({ ...emptyVehicle, ...vehicle });
    setShowForm(true);
    setError("");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setError("");
    setIsSaving(true);

    const payload = buildPayload(formData);

    try {
      if (isEditing) {
        const updated = isApiMode
          ? await updateVehicleApi(selectedVehicle.id, payload)
          : { ...payload, id: selectedVehicle.id, image: formData.image };

        setVehicles((current) =>
          current.map((vehicle) =>
            vehicle.id === selectedVehicle.id ? updated : vehicle,
          ),
        );
        setSelectedVehicle(updated);
        setFormData({ ...emptyVehicle, ...updated });
        return;
      }

      const created = isApiMode
        ? await createVehicleApi(payload)
        : { ...payload, id: Date.now(), image: formData.image };

      setVehicles((current) => [created, ...current]);
      setSelectedVehicle(created);
      setFormData({ ...emptyVehicle, ...created });
      setShowForm(true);
    } catch {
      setError("Unable to save vehicle record.");
    } finally {
      setIsSaving(false);
    }
  };

  const filteredVehicles = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    const matches = vehicles.filter((vehicle) => {
      if (!query) {
        return true;
      }

      return [
        vehicle.model_name,
        vehicle.registration_number,
        vehicle.vehicle_type,
        vehicle.status,
      ]
        .join(" ")
        .toLowerCase()
        .includes(query);
    });

    return [...matches].sort((a, b) => {
      if (sortKey === "status") {
        return (a.status || "").localeCompare(b.status || "");
      }
      if (sortKey === "vehicle_type") {
        return (a.vehicle_type || "").localeCompare(b.vehicle_type || "");
      }
      return (a.model_name || "").localeCompare(b.model_name || "");
    });
  }, [searchTerm, sortKey, vehicles]);

  // Backend has no delete endpoint, so removal is local to the current view.
  const handleDelete = () => {
    if (!selectedVehicle) {
      return;
    }

    setVehicles((current) =>
      current.filter((vehicle) => vehicle.id !== selectedVehicle.id),
    );
    setSelectedVehicle(null);
    setFormData(emptyVehicle);
    setShowForm(false);
  };

  return (
    <div className="vehicle-page">
      <div className="vehicle-actions">
        <div className="vehicle-toolbar">
          <p>
            {isLoading
              ? "Loading records..."
              : `${filteredVehicles.length} records`}
            <span className="vehicle-mode-label">
              {isApiMode ? "API Mode" : "Dummy Mode"}
            </span>
          </p>
          <div className="vehicle-filter-bar">
            <input
              type="text"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder="Search vehicles"
            />
            <select
              value={sortKey}
              onChange={(event) => setSortKey(event.target.value)}
            >
              <option value="model_name">Sort by model</option>
              <option value="status">Sort by status</option>
              <option value="vehicle_type">Sort by type</option>
            </select>
          </div>
        </div>
        <button
          type="button"
          className="create-vehicle-btn"
          onClick={handleCreate}
        >
          Add Vehicle
        </button>
      </div>

      {error && <p className="vehicle-error">{error}</p>}

      <div className="vehicle-manager">
        {isLoading ? (
          <TrackLoader label="Loading vehicles..." />
        ) : (
          <VehicleGrid
            vehicles={filteredVehicles}
            selectedVehicleId={selectedVehicle?.id}
            onSelectVehicle={handleSelect}
          />
        )}

        {showForm && (
          <form className="vehicle-form" onSubmit={handleSubmit}>
            <div className="vehicle-form-header">
              <div>
                <h2>{isEditing ? "Edit Vehicle" : "Create Vehicle"}</h2>
                <p>{isEditing ? formData.registration_number : "New record"}</p>
              </div>

              <button
                type="button"
                className="close-form-btn"
                aria-label="Close vehicle form"
                onClick={() => setShowForm(false)}
              >
                x
              </button>
            </div>

            <label>
              Registration Number
              <input
                name="registration_number"
                value={formData.registration_number}
                onChange={handleChange}
                placeholder="TN01AB1234"
                required
              />
            </label>

            <label>
              Model Name
              <input
                name="model_name"
                value={formData.model_name}
                onChange={handleChange}
                placeholder="Toyota Fortuner"
                required
              />
            </label>

            <label>
              Vehicle Type
              <input
                name="vehicle_type"
                value={formData.vehicle_type}
                onChange={handleChange}
                placeholder="SUV"
                required
              />
            </label>

            <div className="vehicle-form-row">
              <label>
                Max Load (kg)
                <input
                  name="max_load_capacity"
                  type="number"
                  min="1"
                  value={formData.max_load_capacity}
                  onChange={handleChange}
                  placeholder="750"
                  required
                />
              </label>

              <label>
                Odometer (km)
                <input
                  name="odometer"
                  type="number"
                  min="0"
                  value={formData.odometer}
                  onChange={handleChange}
                  placeholder="48200"
                />
              </label>
            </div>

            <label>
              Acquisition Cost (₹)
              <input
                name="acquisition_cost"
                type="number"
                min="0"
                value={formData.acquisition_cost}
                onChange={handleChange}
                placeholder="3800000"
              />
            </label>

            <label>
              Status
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
              >
                <option>Available</option>
                <option>On Trip</option>
                <option>In Shop</option>
                <option>Retired</option>
              </select>
            </label>

            <label>
              Image URL (optional)
              <input
                name="image"
                value={formData.image || ""}
                onChange={handleChange}
                placeholder="https://..."
              />
            </label>

            <div className="vehicle-form-buttons">
              <button
                type="submit"
                className="save-vehicle-btn"
                disabled={isSaving}
              >
                {isSaving
                  ? "Saving..."
                  : isEditing
                    ? "Save Changes"
                    : "Create Record"}
              </button>

              {isEditing && (
                <button
                  type="button"
                  className="delete-vehicle-btn"
                  onClick={handleDelete}
                  disabled={isSaving}
                >
                  Delete
                </button>
              )}
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

export default Vehicle;
