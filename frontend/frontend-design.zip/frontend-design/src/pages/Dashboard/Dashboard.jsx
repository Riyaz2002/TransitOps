import { useMemo } from "react";
import "./Dashboard.css";
import vehicles from "../../data/vehicles";
import drivers from "../../data/drivers";
import trips from "../../data/trips";

const iconProps = {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
};

const icons = {
  vehicles: (
    <svg {...iconProps} aria-hidden="true">
      <rect x="1" y="4" width="15" height="12" rx="1.5" />
      <path d="M16 8h3.5L23 11.5V16H16z" />
      <circle cx="6" cy="18.5" r="2" />
      <circle cx="18" cy="18.5" r="2" />
    </svg>
  ),
  trips: (
    <svg {...iconProps} aria-hidden="true">
      <polygon points="1 6 8 3 16 6 23 3 23 18 16 21 8 18 1 21" />
      <line x1="8" y1="3" x2="8" y2="18" />
      <line x1="16" y1="6" x2="16" y2="21" />
    </svg>
  ),
  drivers: (
    <svg {...iconProps} aria-hidden="true">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  ),
  check: (
    <svg {...iconProps} aria-hidden="true">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  ),
};

function Dashboard() {
  const { stats, utilization, totalVehicles } = useMemo(() => {
    const total = vehicles.length;
    const available = vehicles.filter((v) => v.status === "Available").length;
    const inUse = vehicles.filter((v) => v.status === "In Use").length;
    const maintenance = vehicles.filter(
      (v) => v.status === "Maintenance",
    ).length;
    const activeTrips = trips.filter(
      (t) => t.status !== "Completed" && t.status !== "Cancelled",
    ).length;
    const availableDrivers = drivers.filter(
      (d) => d.status === "Available",
    ).length;

    const pct = (n) => (total ? Math.round((n / total) * 100) : 0);

    return {
      totalVehicles: total,
      stats: [
        {
          label: "Total Vehicles",
          value: total,
          sub: "In the fleet",
          tone: "brand",
          icon: "vehicles",
        },
        {
          label: "Active Trips",
          value: activeTrips,
          sub: "In motion now",
          tone: "info",
          icon: "trips",
        },
        {
          label: "Available Drivers",
          value: availableDrivers,
          sub: "Ready to dispatch",
          tone: "success",
          icon: "drivers",
        },
        {
          label: "Available Vehicles",
          value: available,
          sub: "Idle & ready",
          tone: "warning",
          icon: "check",
        },
      ],
      utilization: [
        {
          label: "Available",
          value: available,
          tone: "success",
          pct: pct(available),
        },
        { label: "In Use", value: inUse, tone: "warning", pct: pct(inUse) },
        {
          label: "Maintenance",
          value: maintenance,
          tone: "danger",
          pct: pct(maintenance),
        },
      ],
    };
  }, []);

  return (
    <div className="dashboard-page">
      <section className="dash-hero">
        <div className="dash-hero-text">
          <p className="dash-eyebrow">Operations overview</p>
          <h2>Fleet health at a glance</h2>
          <p className="dash-copy">
            Track fleet activity, active trips, and resource availability in one
            calm, connected view.
          </p>
        </div>
        <div className="dash-hero-badge">
          <span className="dash-live-dot" />
          Live fleet summary
        </div>
      </section>

      <section className="dash-stats">
        {stats.map((item) => (
          <article key={item.label} className={`dash-stat ${item.tone}`}>
            <span className="dash-stat-icon">{icons[item.icon]}</span>
            <div className="dash-stat-body">
              <span className="dash-stat-label">{item.label}</span>
              <strong className="dash-stat-value">{item.value}</strong>
              <span className="dash-stat-sub">{item.sub}</span>
            </div>
          </article>
        ))}
      </section>

      <section className="dash-panels">
        <article className="dash-panel dash-panel--wide">
          <div className="dash-panel-head">
            <h3>Fleet utilization</h3>
            <span className="dash-chip">{totalVehicles} vehicles</span>
          </div>
          <div className="dash-bars">
            {utilization.map((bar) => (
              <div key={bar.label} className="dash-bar-row">
                <div className="dash-bar-top">
                  <span className="dash-bar-label">{bar.label}</span>
                  <span className="dash-bar-value">
                    {bar.value} · {bar.pct}%
                  </span>
                </div>
                <div className="dash-bar-track">
                  <div
                    className={`dash-bar-fill ${bar.tone}`}
                    style={{ width: `${bar.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </article>

        <article className="dash-panel">
          <div className="dash-panel-head">
            <h3>Recent operations</h3>
          </div>
          <ul className="dash-list">
            <li>3 trips are currently in motion.</li>
            <li>2 drivers are on duty today.</li>
            <li>Vehicle availability remains strong.</li>
          </ul>
        </article>

        <article className="dash-panel">
          <div className="dash-panel-head">
            <h3>Quick focus</h3>
          </div>
          <ul className="dash-list">
            <li>Review dispatched trips before departure.</li>
            <li>Confirm maintenance vehicles are offline.</li>
            <li>Balance driver shifts for evening deliveries.</li>
          </ul>
        </article>
      </section>
    </div>
  );
}

export default Dashboard;
