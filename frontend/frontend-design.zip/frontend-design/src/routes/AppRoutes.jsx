import { Routes, Route } from "react-router-dom";

import Login from "../pages/Login/Login";
import Dashboard from "../pages/Dashboard/Dashboard";
import Vehicle from "../pages/Vehicle/Vehicle";
import Driver from "../pages/Driver/Driver";
import Trip from "../pages/Trip/Trip";
import Layout from "../layouts/layout";

function AppRoutes({ darkMode, setDarkMode, dataMode, setDataMode }) {
  return (
    <Routes>
      <Route
        path="/"
        element={
          <Login
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            dataMode={dataMode}
            setDataMode={setDataMode}
          />
        }
      />

      <Route element={<Layout darkMode={darkMode} setDarkMode={setDarkMode} />}>
        <Route path="/dashboard" element={<Dashboard />} />

        <Route path="/vehicle" element={<Vehicle dataMode={dataMode} />} />

        <Route path="/driver" element={<Driver dataMode={dataMode} />} />

        <Route path="/trip" element={<Trip dataMode={dataMode} />} />
      </Route>
    </Routes>
  );
}

export default AppRoutes;
